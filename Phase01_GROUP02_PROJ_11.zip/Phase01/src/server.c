#include <stdio.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include<dirent.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdbool.h>
#include <unistd.h>
#include <limits.h>
#include "server.h"
#include "request.h"
#include <errno.h>
#include "registry.h"

#define BUFFER_SIZE 1024
volatile bool server_running = true;
int serverSocket;

void handleArguements(int argc, char *argv[], int *portNumber, char *dataFilePath)
{

        for (int i = 0; i < argc; ++i) {
                if(strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
                        *portNumber = atoi(argv[i + 1]);
                        ++i;
                }
                else if(strcmp(argv[i], "--data") == 0 && i + 1 < argc) {
                        strcpy(dataFilePath, argv[i + 1]);
                        ++i;
                }
        }
}

void* handleClient(void* arg) {
        int clientSocket = *(int*)arg;

        free(arg);
        Request *request = NULL;
        char buffer[BUFFER_SIZE];

        while (1) {
                int bytes = recv(clientSocket, buffer, BUFFER_SIZE - 1, 0);
                // printf("%d", bytes);

                if (bytes <= 0) {
                        printf("Client disconnected\n");
                        break;
                }

                buffer[bytes] = '\0';
                request = getRequest(buffer);
                if (request == NULL) {
                        send(clientSocket, "Invalid Command!", 17, 0);
                        continue;
                }
                
                printf("Client says: %s\n", buffer);

                Response response = ProcessRequest(request);

                if (response.runFurther == false)
                {
                        send(clientSocket,"quit" , 4, 0);
                        break;
                }
                if(response.result == NULL) {
                        if (send(clientSocket, "ok", 2, 0) < 0) {
                                perror("send failed");
                                break;
                        }
                }
                else {
                        if(request->bucketSeconds <= 0) {
                                if (send(clientSocket, "No data Found!", 15, 0) < 0) {
                                        perror("send failed");
                                        break;
                                }
                        }
                        else if (send(clientSocket, response.result, strlen(response.result), 0) < 0)
                        {
                                perror("send failed");
                                break;
                        }
                        printf("%s\n", response.result);
                        free(response.result);
                }

                free(request);
                //  PUT cpu.usage 1728000000 45.2 
                // GET cpu.usage 1728000000 1728000005
                // send(clientSocket, buffer, bytes, 0);

                // PUT cpu.usage 1728000000 45.2
                // ok
                // > PUT cpu.usage 1728000001 34.5
                // ok
                // > PUT cpu.usage 1728000002 34.3
                // ok
                // > PUT cpu.usage 1728000005 45.0
                // ok
                // > PUT cpu.usage 1728000007 31.0
                // ok
                // > GET cpu.usage 1728000000 1728000005
                // > STATS cpu.usage
        }
        close(clientSocket);
        return NULL;
}

bool createPthreadForUsers(int clientSocket)
{
        pthread_t tid;

        int *pclient = malloc(sizeof(int));
        if (!pclient) {
                perror("malloc failed!");
                close(clientSocket);
                return false;
        }
        *pclient = clientSocket;

        if (pthread_create(&tid, NULL, handleClient, pclient) != 0) {
                perror("Thread creation failed");
                free(pclient);
                close(clientSocket);
                return false;
        }

        pthread_detach(tid);
        return true;
}

void createAndRunServer(const int portNumber, char *dataFilePath) {
        int clientSocket;
        struct sockaddr_in serverAddress, clientAddress;

        serverSocket = socket(AF_INET, SOCK_STREAM, 0);

        serverAddress.sin_family = AF_INET;
        serverAddress.sin_port = htons(portNumber);
        serverAddress.sin_addr.s_addr = INADDR_ANY;

        // bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress));
        // listen(serverSocket, 10);
        int opt = 1;
        setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
                perror("bind failed");
                exit(1);
        }

        if (listen(serverSocket, 128) < 0) {
                perror("listen failed");
                exit(1);
        }

        printf("Server listening on port %d...\n", portNumber);

        signal(SIGINT, handle_shutdown);
        signal(SIGTERM, handle_shutdown);
        socklen_t addressSize;

        loadRegistry(dataFilePath);
        while (server_running)
        {
                addressSize = sizeof(clientAddress);
                clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddress, &addressSize);
                // printf("cs : %d", clientSocket);
                if (clientSocket < 0) {
                        if (!server_running) 
                                break;
                        if (errno == EINTR || errno == EBADF)
                                break;
                        perror("Accept failed");
                        continue;
                }
                printf("New client connected!\n");

                createPthreadForUsers(clientSocket);
                
        }
        
        printf("Server shutting down...\n");
        cleanupRegistry();
        
}

void handle_shutdown(int sig)
{
    server_running = false;
    close(serverSocket);
}


void loadRegistry(char* dataFilePath)
{
        DIR *dir = opendir(dataFilePath);
        if (!dir) {
                perror("opendir");
                return;
        }

        struct dirent *entry;

        while ((entry = readdir(dir)) != NULL) {

                if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                        continue;

                char full_path[512];
                snprintf(full_path, sizeof(full_path), "%s/%s", dataFilePath, entry->d_name);

                struct stat st;
                if (stat(full_path, &st) == -1) {
                        perror("stat");
                        continue;
                }

                if (S_ISDIR(st.st_mode)) {
                        getMetricFromHashTable(entry->d_name, true);
                        printf("Metric directory: %s\n", entry->d_name);
                }

                
        }
        closedir(dir);
}